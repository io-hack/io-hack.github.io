#!/bin/sh
JLinkExe -JLinkScriptFile ./jlink-script/ConnectCore`echo $1`.JLinkScript
