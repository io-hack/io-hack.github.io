#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <asm/io.h>

#define MEM32(addr) (*((volatile unsigned long*)(addr)))

volatile unsigned long vir_addr,phy_addr;
volatile unsigned long old_val;

static int __init jtag_set_init(void)
{
	printk("module init(start).\n");

	phy_addr = 0x01C20800;

	vir_addr = (volatile unsigned long)ioremap(phy_addr, 0x00000004);

	printk("0x%08lX = 0x%08lX\n", phy_addr, MEM32(vir_addr));

	/* save */
	old_val = 0xFFFF & MEM32(vir_addr);

	/* clear */
	MEM32(vir_addr) &= (~0xFFFF);

	printk("0x%08lX = 0x%08lX\n", phy_addr, MEM32(vir_addr));

	/* set */
	MEM32(vir_addr) |= (0x3333);

	printk("0x%08lX = 0x%08lX\n", phy_addr, MEM32(vir_addr));

	printk("module init(end).\n");

	return 0;
}

static void __exit jtag_set_exit(void)
{
	printk("module exit(start).\n");

	printk("0x%08lX = 0x%08lX\n", phy_addr, MEM32(vir_addr));

	/* clear */
	MEM32(vir_addr) &= (~0xFFFF);

	printk("0x%08lX = 0x%08lX\n", phy_addr, MEM32(vir_addr));

	/* set */
	MEM32(vir_addr) |= old_val;

	printk("0x%08lX = 0x%08lX\n", phy_addr, MEM32(vir_addr));

	printk("module exit(end).\n");
}

module_init(jtag_set_init);
module_exit(jtag_set_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("GSK Jin <zhenwenjin@gmail.com>");
MODULE_VERSION("1.1");
