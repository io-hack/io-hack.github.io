/**************************************
 * �ļ���  ��main.c
 * ����    �������ϵ�LED1��˸��         
 * ʵ��ƽ̨��MINI STM32������ ����STM32F103C8T6
 * ��汾  ��ST3.0.0  																										  

*********************************************************/	

#include "stm32f10x.h"
#include "led.h"

#define LCD_H 240
#define LCD_W 480

void Delay(__IO u32 nCount);


void lcd_init()
{
	SDA_OUT();
  CS_H();
  SDA_L();
  CLK_L();
	
	//reset
	GRSTB_H();
	Delay(0xfffff);
	GRSTB_L();
	Delay(0xfffff);
	GRSTB_H();
	Delay(0xfffff);
	//reset
}

void spi_write(unsigned char addr, unsigned char val)
{
	int i;
	SDA_OUT();
	CLK_L();
	SDA_L();
	CS_L();
	
	//addr
	for(i=0;i<6;i++)
	{
		CLK_L();
		if((addr << i) & 0x20)
		{
			SDA_H();
		}
		else
		{
			SDA_L();
		}
		CLK_H();
	}
	//addr
	
	//R/W HiZ
	CLK_L();
	SDA_L(); //L write
	CLK_H();
	
	CLK_L();
	SDA_H();
	CLK_H();
	//R/W HiZ
	
	//WRITE
	for(i=7;i>=0;i--)
	{
		CLK_L();
		if((val >> i) & 0x1)
		{
			SDA_H();
		}
		else
		{
			SDA_L();
		}
		CLK_H();
	}
	//WRITE
	

	SDA_L();
	CLK_L();
	
	CS_H();
	
}

unsigned char spi_read(unsigned char addr)
{
	int i;
	unsigned char data;
	data = 0;
	SDA_OUT();
	CLK_L();
	SDA_L();
	CS_L();
	
	//addr
	for(i=0;i<6;i++)
	{
		CLK_L();
		if((addr << i) & 0x20)
		{
			SDA_H();
		}
		else
		{
			SDA_L();
		}
		CLK_H();
	}
	//addr
	
	//R/W HiZ
	CLK_L();
	SDA_H();
	CLK_H();
	
	CLK_L();
	SDA_L();
	CLK_H();
	//R/W HiZ
	
	//READ
	SDA_IN();
	for(i=7;i>=0;i--)
	{
		CLK_L();
		if(SDA_RD())
		{
			data |= 0x1 << i;
		}
		CLK_H();
	}
	//READ
	
	SDA_OUT();
	SDA_L();
	CLK_L();
	
	CS_H();
	
	return data;
	
}

#include <stdio.h>
int fputc(int ch, FILE* stream)
{
    USART_SendData(USART1, (unsigned char) ch);
    while (!(USART1->SR & USART_FLAG_TXE));
    return ch;
}

int main(void)
{
	unsigned char data;
	unsigned int init_ok = 0;
	SystemInit();	// ����ϵͳʱ��Ϊ72M 	
	//while(1);
	LED_GPIO_Config(); //LED �˿ڳ�ʼ��

	lcd_init();
	
	data = spi_read(0x2);
	data &= ~(0x3 << 0);
	data |= 0x2; //through mode
	spi_write(0x2, data);
	if(spi_read(0x2) == data)
	{
		printf("through mode ok !\r\n");
		init_ok++;
	}
	else
	{
		printf("through mode failed !\r\n");
	}
	
	data = spi_read(0x3);
	data &= ~(0x1 << 0);
	data |= 0x1; //Non-interlace
	spi_write(0x3, data);
	if(spi_read(0x3) == data)
	{
		printf("Non-interlace ok !\r\n");
		init_ok++;
	}
	else
	{
		printf("Non-interlace failed !\r\n");
		
	}
	//DIY����ͶӰ Ⱥ��:210177425
	//DIY����ͶӰ Ⱥ��:210177425
	//DIY����ͶӰ Ⱥ��:210177425
	//DIY����ͶӰ Ⱥ��:210177425
	//DIY����ͶӰ Ⱥ��:210177425
	//DIY����ͶӰ Ⱥ��:210177425
	//DIY����ͶӰ Ⱥ��:210177425
	//DIY����ͶӰ Ⱥ��:210177425
	//DIY����ͶӰ Ⱥ��:210177425
  while (1)
  {
		if(init_ok == 2)
		{
			LED1(ON);
			Delay(0x8ffff);
			LED1(OFF);
			Delay(0x8ffff);
		}
		else
		{
			LED1(OFF);
		}
  }
}

void Delay(__IO u32 nCount)
{
  for(; nCount != 0; nCount--);
} 



