#ifndef __LED_H
#define	__LED_H

#include "stm32f10x.h"

/* the macro definition to trigger the led on or off 
 * 1 - off
 - 0 - on
 */
#define ON  0
#define OFF 1

#define LED1(a)	if (a)	\
					GPIO_SetBits(GPIOC,GPIO_Pin_13);\
					else		\
					GPIO_ResetBits(GPIOC,GPIO_Pin_13)
					
//			A0 CS A1 CLK A2 SDA
//IDLE     H     L      L
					
#define CS_H() GPIO_SetBits(GPIOA,GPIO_Pin_0)
#define CS_L() GPIO_ResetBits(GPIOA,GPIO_Pin_0)
					
#define CLK_H() GPIO_SetBits(GPIOA,GPIO_Pin_1)
#define CLK_L() GPIO_ResetBits(GPIOA,GPIO_Pin_1)
					
#define SDA_H() GPIO_SetBits(GPIOA,GPIO_Pin_2)
#define SDA_L() GPIO_ResetBits(GPIOA,GPIO_Pin_2)
#define SDA_RD() GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2)
					
#define GRSTB_H() GPIO_SetBits(GPIOA,GPIO_Pin_3)
#define GRSTB_L() GPIO_ResetBits(GPIOA,GPIO_Pin_3)
					
void SDA_IN(void);
void SDA_OUT(void);

void LED_GPIO_Config(void);

#endif /* __LED_H */
